// ------ You Can Hide Ringba Badge By Changing The Value To False
var showCredits = true;
    // ------------------------------------